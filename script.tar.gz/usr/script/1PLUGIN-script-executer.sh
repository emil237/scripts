
#!/bin/sh
#

wget -O /var/volatile/tmp/script-executer.tar.gz "https://raw.githubusercontent.com/emil237/plugins/main/script-executer.tar.gz"
wait
tar xzvpf /tmp/*.tar.gz -C /
wait

sleep 2;
exit 0



































