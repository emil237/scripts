wget -q "--no-check-certificate" https://raw.githubusercontent.com/emil237/E2IPLAYER_TSiplayer/main/e2iplayer.sh -O - | /bin/sh


