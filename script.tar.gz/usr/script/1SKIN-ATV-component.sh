opkg install --force-overwrite  https://raw.githubusercontent.com/emil237/skins-openatv/main/skins-component-army-atv_all.ipk
wait
sleep 2;
exit 0










