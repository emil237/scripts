opkg install --force-reinstall  https://raw.githubusercontent.com/emil237/skins-OpenPli/main/Skin-My-Vali-HD-nano-By-Vali-MOD-RAED.ipk
wait
sleep 2;
exit 0
