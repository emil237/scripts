#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/emil237/skins-openatv/main/SKIN-ORANGESKY-XP-FHD-By-Muaath.tar.gz"
wait
tar -xzf SKIN-ORANGESKY-XP-FHD-By-Muaath.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/SKIN-ORANGESKY-XP-FHD-By-Muaath.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0



















