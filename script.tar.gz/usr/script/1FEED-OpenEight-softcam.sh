opkg install --force-overwrite  http://178.63.156.75/paneladdons/Feeds/OpenEight/enigma2-plugin-softcam.feed-openeight_6.6_all.ipk
wait
sleep 2;
exit 0







