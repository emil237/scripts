wget -q "--no-check-certificate" https://raw.githubusercontent.com/emil237/DreamOSatcamManager/main/installer.sh -O - | /bin/sh



