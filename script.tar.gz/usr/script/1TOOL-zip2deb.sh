wget http://tunisia-dreambox.info/TSplugins/zip2deb/installer.sh -O - | /bin/sh




