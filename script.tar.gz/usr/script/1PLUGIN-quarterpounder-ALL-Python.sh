wget
https://raw.githubusercontent.com/emil237/quarterpounder/main/installer.sh -O - | /bin/sh



