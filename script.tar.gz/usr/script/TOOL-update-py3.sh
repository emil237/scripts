opkg update
opkg install wget curl  python3-lxml python3-requests python3-beautifulsoup4 python3-cfscrape ;opkg install livestreamersrv python3-six python3-sqlite3 python3-pycrypto f4mdump python3-image ;opkg install python3-imaging python3-argparse python3-multiprocessing python3-mmap ;opkg install python3-ndg-httpsclient python3-pydoc python3-xmlrpc python3-certifi python3-urllib3 ;opkg install python3-chardet python3-pysocks python3-js2py python3-pillow
wait
exit 0

























