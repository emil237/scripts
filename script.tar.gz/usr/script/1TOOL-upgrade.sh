opkg update
opkg upgrade
reboot
wait
sleep 2;
exit 0
