wget -q "--no-check-certificate" https://raw.githubusercontent.com/emil237/Download/main/freeserver/installer.sh -O - | /bin/sh









