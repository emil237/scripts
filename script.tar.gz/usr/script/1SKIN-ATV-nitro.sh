opkg install --force-overwrite  https://raw.githubusercontent.com/emil237/skins-openatv/main/skins-nitro-fhd-all.ipk
wait
sleep 2;
exit 0













