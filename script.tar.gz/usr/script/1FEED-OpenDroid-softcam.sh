opkg install --force-overwrite  http://178.63.156.75/paneladdons/Feeds/OPD/softcam-feed-opd_7.0_all.ipk
wait
sleep 2;
exit 0
