wget https://raw.githubusercontent.com/emil237/picon-other/main/installer.sh -qO - | /bin/sh




