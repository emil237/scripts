opkg install --force-reinstall  https://raw.githubusercontent.com/emil237/skins-openatv/main/skins-darkness-fhd_all.ipk
wait
sleep 2;
exit 0









