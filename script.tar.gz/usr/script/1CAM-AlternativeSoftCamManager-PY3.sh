#!/bin/sh
#
#
version=3.0
#############################################################
TEMPATH=/tmp
PLUGINPATH=/usr/lib/enigma2/python/Plugins/Extensions/AlternativeSoftCamManager

# remove old version
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/AlternativeSoftCamManager


echo ""
# Download and install plugin
cd /tmp
set -e
echo "===> Downloading And Installing AlternativeSoftCamManager plugin Please Wait ......"
echo
wget "https://raw.githubusercontent.com/emil237/plugins/main/AlternativeSoftCamManager_py3.tar.gz"
tar -xzf AlternativeSoftCamManager_py3.tar.gz -C /
set +e
rm -f AlternativeSoftCamManager_py3.tar.gz
set +e
cd ..
echo ""
sync
echo "################################################################"
echo "#    AlternativeSoftCamManager $version INSTALLED SUCCESSFULLY #"
sleep 4;
echo "################################################################"
echo "**************************************************************"
echo "################################################################"
echo "#              your Device will RESTART Now                    #"
echo "################################################################"
sleep 3
wait
killall -9 enigma2
exit 0
