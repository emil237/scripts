opkg install --force-reinstall  https://raw.githubusercontent.com/emil237/skins-OpenPli/main/Skin-Pal.6.FullHD_OpenPLi7_all.ipk
wait
sleep 2;
exit 0











