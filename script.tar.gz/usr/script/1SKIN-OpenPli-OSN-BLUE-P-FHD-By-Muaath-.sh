opkg install --force-overwrite  https://raw.githubusercontent.com/emil237/skins-OpenPli/main/Skin-OSN-BLUE-P-FHD-By-Muaath.ipk
wait
sleep 2;
exit 0



