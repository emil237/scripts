wget https://raw.githubusercontent.com/emil237/tspanel/main/installer.sh -O - | /bin/sh


