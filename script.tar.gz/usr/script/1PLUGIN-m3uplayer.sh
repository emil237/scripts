wget https://raw.githubusercontent.com/emil237/m3uplayer/main/installer.sh -O - | /bin/sh


