wget https://raw.githubusercontent.com/emiln237/arabiclanguage/main/installer.sh -O - | /bin/sh


