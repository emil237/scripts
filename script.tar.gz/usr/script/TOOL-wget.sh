opkg install wget
opkg install curl
