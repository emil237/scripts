opkg install --force-overwrite  http://178.63.156.75/paneladdons/Feeds/TeamBlue/cam4-teamblue_1_all.ipk
wait
sleep 2;
exit 0






