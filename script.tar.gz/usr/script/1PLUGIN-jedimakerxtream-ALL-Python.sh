wget https://raw.githubusercontent.com/emil237/jedimakerxtream/main/installer.sh -qO - | /bin/sh


