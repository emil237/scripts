wget https://raw.githubusercontent.com/emil237/picon-Badr26E/main/installer.sh -qO - | /bin/sh  

