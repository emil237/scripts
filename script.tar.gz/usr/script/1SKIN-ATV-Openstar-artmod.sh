wget http://tropical.jungle-team.online/script/jungle-feed.conf -P /etc/opkg/

opkg update

opkg install --force-overwrite enigma2-plugin-skins-openstar-artmod

