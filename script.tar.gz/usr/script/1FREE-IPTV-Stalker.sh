#!/bin/sh
#

wget -O /home/stalker.conf "https://drive.google.com/uc?id=1MI8cvhOr7wieOs-9XTJkfbjJMUqx3pgm&export=download"

exit 0



