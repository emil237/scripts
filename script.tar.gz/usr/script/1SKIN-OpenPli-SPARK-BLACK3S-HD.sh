#!/bin/sh
#

wget -O /var/volatile/tmp/skins-SPARK-BLACK3S.ipk "https://raw.githubusercontent.com/emil237/skins-OpenPli/main/skins-SPARK-BLACK3S.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
sleep 2;
exit 0










