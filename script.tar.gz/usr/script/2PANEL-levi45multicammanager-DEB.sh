#!/bin/sh
echo "Installing levi45multicammanager "
sleep 1
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/download-plugins/main/levi45multicammanager_all.deb" > /tmp/levi45multicammanager_all.deb
sleep 1
echo "install levi45multicammanager...."
cd /tmp
dpkg -i /tmp/levi45multicammanager_all.deb
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/levi45multicammanager_all.deb
sleep 2
killall -9 enigma2
exit
















