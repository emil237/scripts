#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/emil237/plugins/main/ncamstatus_py3.tar.gz"
wait
tar -xzf NcamStatus_py3.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/NcamStatus_py3.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0



















