wget -q "--no-check-certificate" http://ipkinstall.ath.cx/ipk-install/PY3/NcamStatus/installer.sh -O - | /bin/sh





