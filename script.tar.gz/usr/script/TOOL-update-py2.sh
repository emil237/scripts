opkg update
opkg install wget curl  hlsdl python-lxml python-requests python-beautifulsoup4 python-cfscrape ;opkg install livestreamer livestreamersrv python-six python-sqlite3 python-pycrypto f4mdump python-image ;opkg install python-imaging python-argparse python-multiprocessing python-mmap ;opkg install python-ndg-httpsclient python-pydoc python-xmlrpc python-certifi python-urllib3 ;opkg install python-chardet python-pysocks
wait
sleep 2;
exit 0
