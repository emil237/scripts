opkg install --force-overwrite  https://raw.githubusercontent.com/emil237/skins-openatv/main/skins-nacht_1.7.3_DunkelHD_all.ipk
wait
sleep 2;
exit 0



