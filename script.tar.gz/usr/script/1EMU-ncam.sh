wget https://raw.githubusercontent.com/emil237/ncam/main/installer.sh -O - | /bin/sh



