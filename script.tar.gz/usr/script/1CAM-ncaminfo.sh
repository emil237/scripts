#!/bin/sh
#

wget -O /var/volatile/tmp/ncaminfo_1.1_all.ipk "https://raw.githubusercontent.com/emil237/plugins/main/ncaminfo_1.1_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/ncaminfo_1.1_all.ipk
wait
sleep 2;
exit


