wget https://raw.githubusercontent.com/emil237/picon-eutelsat_16E/main/installer.sh -qO - | /bin/sh 

