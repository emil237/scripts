opkg install --force-reinstall  https://raw.githubusercontent.com/emil237/skins-blackhole/main/skin-ekselancen_20190630-r01_all.ipk
wait
sleep 2;
exit 0










