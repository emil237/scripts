wget https://raw.githubusercontent.com/emil237/channel-mohamed-saad/main/installer.sh -qO - | /bin/sh



