wget -O /etc/tuxbox/satellites.xml "https://raw.githubusercontent.com/OpenPLi/tuxbox-xml/master/xml/satellites.xml"
wait
sleep 3;
init 4
init 3
exit 0













