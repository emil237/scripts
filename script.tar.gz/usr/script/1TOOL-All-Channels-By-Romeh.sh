wget https://raw.githubusercontent.com/emil237/channel-romeh/main/installer.sh -qO - | /bin/sh



