opkg install --force-overwrite  https://raw.githubusercontent.com/emil237/skins-blackhole/main/skin-enigma2-alienaware-obh4_all.ipk
wait
sleep 2;
exit 0










