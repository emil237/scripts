wget -q "--no-check-certificate" http://ipkinstall.ath.cx/ipk-install/PY3/OscamStatus/installer.sh -O - | /bin/sh
