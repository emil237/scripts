#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/emil237/skins-OpenPli/main/PLi-FullNight-S-Xtra-FHD.tar.gz"
wait
tar -xzf PLi-FullNight-S-Xtra-FHD.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/PLi-FullNight-S-Xtra-FHD.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0
























