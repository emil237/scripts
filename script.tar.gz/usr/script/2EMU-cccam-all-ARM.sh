#!/bin/sh
echo "Install CCcam 2.3.2 SkyDE"
sleep 1
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/cccam/main/cccam-all-images_2.3.9_all.ipk" > /tmp/cccam-all-images_2.3.9_all.ipk
sleep 1
echo "install CCcam...."
cd /tmp
opkg install /tmp/cccam-all-images_2.3.9_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/cccam-all-images_2.3.9_all.ipk
sleep 2
killall -9 enigma2
exit
