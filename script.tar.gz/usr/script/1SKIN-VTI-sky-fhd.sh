#!/bin/sh
echo "Installing skin-vti "
sleep 1
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/skin-vti/main/skin-sky-fhd_3.6_all.ipk" > /tmp/skin-sky-fhd_3.6_all.ipk
sleep 1
echo "install skins vti...."
cd /tmp
opkg install /tmp/skin-sky-fhd_3.6_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/skin-sky-fhd_3.6_all.ipk
wait
sleep 2
exit 0






